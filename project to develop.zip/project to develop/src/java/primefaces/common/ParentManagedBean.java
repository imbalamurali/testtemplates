/*
 * ParentManagedBean.java
 *
 * Created on Feb 6, 2018, 3:27:11 PM
 */

package primefaces.common;

import javax.el.ELResolver;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServlet;

/**
 * @since 1.0
 * @author balamurali
 */
public class ParentManagedBean extends HttpServlet
{

    public Object getManagedBeanObject(String className)
    {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ELResolver resolver = facesContext.getApplication().getELResolver();
        return resolver.getValue(facesContext.getELContext(), null, className);
    }
}
