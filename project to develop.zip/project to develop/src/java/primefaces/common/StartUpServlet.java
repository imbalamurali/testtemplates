 /*
 * startupServlet.java
 *
 * Created on Feb 6, 2018, 11:30 AM
 *
 */
package primefaces.common;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import primefaces.login.LanguageSelection;

/**
 * Class description: This Servlet will load log4j properties when application starts up.
 * @author balamurali
 * @since 1.0
 */
public class StartUpServlet extends ParentManagedBean
{

    private Logger logger = Logger.getLogger(getClass().getName());
    public static final String LOGGER_FILE_PATH = "conf" + File.separator + "log4j.properties";
    private String realPath;

    @Override
    public void init()
    {
        logger.info("[FE] - Application startup complete !");
        
        realPath = getServletContext().getRealPath("");
        try
        {
            PropertyConfigurator.configure(realPath + File.separator 
                    + LOGGER_FILE_PATH);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            logger.info("[FE] - Exception occured while configuring log4j.property file!" + ex);
            
        }
        
        LanguageSelection languageSelection = (LanguageSelection) getManagedBeanObject(LanguageSelection.class.getSimpleName());
        languageSelection.fetchLanguageSelectionMethod();
        
        logger.info("=================== Tomcat JVM heap =============================");
        logger.info("max memory: " + Runtime.getRuntime().maxMemory() / (1024 * 1024));
        logger.info("available memory: " + Runtime.getRuntime().freeMemory() / (1024 * 1024));
        logger.info("total memory: " + Runtime.getRuntime().totalMemory() / (1024 * 1024));
        logger.info("================================================================");

    }

    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }
}
