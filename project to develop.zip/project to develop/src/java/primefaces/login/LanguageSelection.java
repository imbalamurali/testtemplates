/*
 * LanguageSelection.java
 *
 * Created on Feb 6, 2018, 3:06:08 PM
 *
 */

package primefaces.login;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;


/**
 * @since 1.0
 * @author balamurali
 */
public class LanguageSelection 
{
    private Map<String, String> languageMap = new HashMap<String, String>();
    private List<SelectItem> languageItemList = new ArrayList<SelectItem>();
    private Logger logger = Logger.getLogger(getClass());

    public void fetchLanguageSelectionMethod()
    {
        logger.debug("entered into fetchLanguageSelectionMethod !");

        FacesContext facesContext = FacesContext.getCurrentInstance();
        ServletContext servletContext = (ServletContext) facesContext.getExternalContext().getContext();
        String resourceBundlePath = servletContext.getRealPath("") + File.separator + "WEB-INF" + File.separator
                + "classes" + File.separator + "com" + File.separator + "infomindz" + File.separator
                + "platform" + File.separator + "pl" + File.separator + "bundles";

        File rootPathDir = new File(resourceBundlePath);
        String[] fileExtensions =
        {
            "properties"
        };
        Collection collection = org.apache.commons.io.FileUtils.listFiles(rootPathDir, fileExtensions, false);
        Iterator iter = collection.iterator();
        
        logger.debug("[PL] - Number of bundles available: " + collection.size());

        while (iter.hasNext())
        {
            String filename = iter.next().toString();
            filename = StringUtils.substringAfterLast(filename, File.separator);

            if (filename.contains("bundle"))
            {
                filename = StringUtils.remove(filename, "bundle");
                filename = StringUtils.removeStart(filename, "_");
                filename = StringUtils.remove(filename, ".properties");

                if (filename.trim().length() > 0 && filename.contains("_"))
                {
                    String countryCode = StringUtils.substringBefore(filename, "_");
                    String languageCode = StringUtils.substringAfter(filename, "_");

                    Locale locale = new Locale(countryCode, languageCode);
                    languageMap.put(locale.getDisplayLanguage(), locale.getLanguage() + "_"
                            + locale.getCountry());
                    
                    logger.debug("languageMap : " + languageMap);
                    logger.debug("locale.getDisplayLanguage() : " + locale.getDisplayLanguage());
                    
                    languageItemList.add(new SelectItem(locale.getDisplayLanguage()));
                }
                else
                {
                    languageItemList.add(new SelectItem("English"));
                    languageMap.put("English", "en_US");
                }
            }
        }
    }
}
