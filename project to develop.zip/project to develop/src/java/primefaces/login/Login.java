/*
 * Login.java
 *
 * Created on Feb 2, 2018, 3:25:43 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.login;


import org.apache.log4j.Logger;
import javax.faces.component.html.HtmlForm;
import primefaces.common.ParentManagedBean;


/**
 * @since 1.0
 * @author balamurali
 */
public class Login extends ParentManagedBean
{
    private HtmlForm initForm;
    
    private String userLoginName;
    private String userPassword;
    
    private Logger logger = Logger.getLogger(getClass());
    
    public Login()
    {
       
    }
    
    public String signInButtonAction()
    {
        logger.debug("Sign In button clicked !");
        
        logger.debug("userLoginName : " + userLoginName);
        logger.debug("userPassword : " + userPassword);
        
        return "login_successful";
    }
       
    
    /**
     * This method initialize the login Attributes.
     * 
     */
    private void initializeLoginAttributes()
    {
        logger.debug("Entered into login initiaize page attributes !");
        
        userLoginName = "";
        userPassword = "";
    }

    /**
     * @return the userLoginName
     */
    public String getUserLoginName()
    {
        return userLoginName;
    }

    /**
     * @param userLoginName the userLoginName to set
     */
    public void setUserLoginName(String userLoginName)
    {
        this.userLoginName = userLoginName;
    }

    /**
     * @return the userPassword
     */
    public String getUserPassword()
    {
        return userPassword;
    }

    /**
     * @param userPassword the userPassword to set
     */
    public void setUserPassword(String userPassword)
    {
        this.userPassword = userPassword;
    }

    /**
     * @return the initForm
     */
    public HtmlForm getInitForm()
    {
        initializeLoginAttributes();
        return initForm;
    }

    /**
     * @param initForm the initForm to set
     */
    public void setInitForm(HtmlForm initForm)
    {
        this.initForm = initForm;
    }
}
