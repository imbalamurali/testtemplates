/*
 * SignUp.java
 *
 * Created on Feb 6, 2018, 11:34:29 AM
 *
 */

package primefaces.login;

import javax.faces.component.html.HtmlForm;
import org.apache.log4j.Logger;


/**
 * @since 1.0
 * @author balamurali
 */
public class SignUp
{
    private HtmlForm initForm;
    
    private String userLoginName;
    private String firstName;
    private String lastName;
    private String emailId;
    private String userPasswordOne;
    private String userPasswordTwo;
    
    private Logger logger = Logger.getLogger(getClass());
    
    /**
     * This method is for sign up button.
     * 
     * @return 
     */
    public String signUpButtonAction()
    {
        logger.debug("entered into signUpButtonAction !");
        logger.debug("userLoginName : " + userLoginName);
        logger.debug("firstName : " + firstName);
        logger.debug("lastName : " + lastName);
        logger.debug("emailId : " + emailId);
        logger.debug("userPasswordOne : " + userPasswordOne);
        logger.debug("userPasswordTwo : " + userPasswordTwo);

        return "signup_successful";
    }
    
    private void initializeSignUpAttributes()
    {
        logger.debug("entered into sign up initialize page attributes !");
        
        userLoginName = "";
        firstName = "";
        lastName = "";
        emailId = "";
        userPasswordOne = "";
        userPasswordTwo = "";
    }

    /**
     * @return the initForm
     */
    public HtmlForm getInitForm()
    {
        initializeSignUpAttributes();
        return initForm;
    }

    /**
     * @param initForm the initForm to set
     */
    public void setInitForm(HtmlForm initForm)
    {
        this.initForm = initForm;
    }

    /**
     * @return the userLoginName
     */
    public String getUserLoginName()
    {
        return userLoginName;
    }

    /**
     * @param userLoginName the userLoginName to set
     */
    public void setUserLoginName(String userLoginName)
    {
        this.userLoginName = userLoginName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName()
    {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName()
    {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * @return the emailId
     */
    public String getEmailId()
    {
        return emailId;
    }

    /**
     * @param emailId the emailId to set
     */
    public void setEmailId(String emailId)
    {
        this.emailId = emailId;
    }

    /**
     * @return the userPasswordOne
     */
    public String getUserPasswordOne()
    {
        return userPasswordOne;
    }

    /**
     * @param userPasswordOne the userPasswordOne to set
     */
    public void setUserPasswordOne(String userPasswordOne)
    {
        this.userPasswordOne = userPasswordOne;
    }

    /**
     * @return the userPasswordTwo
     */
    public String getUserPasswordTwo()
    {
        return userPasswordTwo;
    }

    /**
     * @param userPasswordTwo the userPasswordTwo to set
     */
    public void setUserPasswordTwo(String userPasswordTwo)
    {
        this.userPasswordTwo = userPasswordTwo;
    }
}
