/*
 * DashBoardDemo.java
 *
 * Created on Nov 16, 2016, 10:30:20 AM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */
package primefaces.testclass;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlForm;
import javax.faces.context.FacesContext;
import org.primefaces.event.CloseEvent;
import org.primefaces.event.DashboardReorderEvent;
import org.primefaces.event.ToggleEvent;
import org.primefaces.model.DashboardColumn;
import org.primefaces.model.DashboardModel;
import org.primefaces.model.DefaultDashboardColumn;
import org.primefaces.model.DefaultDashboardModel;

/**
 * @since 1.0
 * @author balamurali
 */
public class DashBoardDemo implements Serializable
{

    private DashboardModel model;

    @PostConstruct
    public void init()
    {
        model = new DefaultDashboardModel();
        DashboardColumn column1 = new DefaultDashboardColumn();
        DashboardColumn column2 = new DefaultDashboardColumn();
        DashboardColumn column3 = new DefaultDashboardColumn();

        List<String> departmentList = new ArrayList<String>();

        departmentList.add("sports");
        departmentList.add("finance");
        departmentList.add("lifestyle");
        departmentList.add("weather");
        departmentList.add("politics");

        int listSize = departmentList.size();

        if (listSize == 1)
        {
            column1 = new DefaultDashboardColumn();
        }
        else if (listSize == 2)
        {
            column1 = new DefaultDashboardColumn();
            column2 = new DefaultDashboardColumn();
        }
        else
        {
            column1 = new DefaultDashboardColumn();
            column2 = new DefaultDashboardColumn();
            column3 = new DefaultDashboardColumn();
        }

        boolean isFirstColumnAvailable = true;
        boolean isSecondColumnAvailable = false;
        boolean isThirdColumnAvailable = false;

        for (String chartPanelId : departmentList)
        {
            if (isFirstColumnAvailable)
            {
                column1.addWidget(chartPanelId);
                isFirstColumnAvailable = false;
                isSecondColumnAvailable = true;
                isThirdColumnAvailable = false;
            }
            else if (isSecondColumnAvailable)
            {
                column2.addWidget(chartPanelId);
                isFirstColumnAvailable = false;
                isSecondColumnAvailable = false;
                isThirdColumnAvailable = true;
            }
            else if (isThirdColumnAvailable)
            {
                column3.addWidget(chartPanelId);
                isFirstColumnAvailable = true;
                isSecondColumnAvailable = false;
                isThirdColumnAvailable = false;
            }

        }

        if (listSize == 1)
        {
            model.addColumn(column1);
        }
        else if (listSize == 2)
        {
            model.addColumn(column1);
            model.addColumn(column2);
        }
        else
        {
            model.addColumn(column1);
            model.addColumn(column2);
            model.addColumn(column3);
        }
    }
//
//    public void handleReorder(DashboardReorderEvent event)
//    {
//        FacesMessage message = new FacesMessage();
//        message.setSeverity(FacesMessage.SEVERITY_INFO);
//        message.setSummary("Reordered: " + event.getWidgetId());
//        message.setDetail("Item index: " + event.getItemIndex() + ", Column index: " + event.getColumnIndex() + ", Sender index: " + event.getSenderColumnIndex());
//
//        addMessage(message);
//    }

    public void handleClose(CloseEvent event)
    {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Panel Closed", "Closed panel id:'" + event.getComponent().getId() + "'");

        addMessage(message);
    }

    public void handleToggle(ToggleEvent event)
    {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, event.getComponent().getId() + " toggled", "Status:" + event.getVisibility().name());

        addMessage(message);
    }

    private void addMessage(FacesMessage message)
    {
        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    public DashboardModel getModel()
    {
        return model;
    }
}
