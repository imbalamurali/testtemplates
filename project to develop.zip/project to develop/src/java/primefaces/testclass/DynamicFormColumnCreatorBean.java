/*
 * DynamicFormColumnCreatorBean.java
 *
 * Created on May 2, 2017, 2:51:08 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;

import java.util.ArrayList;
import java.util.List;


/**
 * @since 1.0
 * @author balamurali
 */
public class DynamicFormColumnCreatorBean
{

    /**
     * @return the colspan
     */
    public int getColspan()
    {
        return colspan;
    }

    /**
     * @param colspan the colspan to set
     */
    public void setColspan(int colspan)
    {
        this.colspan = colspan;
    }

    /**
     * @return the list
     */
    public List<Integer> getList()
    {
        return list;
    }

    /**
     * @param list the list to set
     */
    public void setList(List<Integer> list)
    {
        this.list = list;
    }
    private int colspan;
    private int columnData;
    private List<Integer> list = new ArrayList<Integer>();

    /**
     * @return the columnData
     */
    public int getColumnData()
    {
        return columnData;
    }

    /**
     * @param columnData the columnData to set
     */
    public void setColumnData(int columnData)
    {
        this.columnData = columnData;
    }
}
