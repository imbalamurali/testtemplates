/*
 * DynamicFormCreator.java
 *
 * Created on Apr 26, 2017, 4:02:12 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */
package primefaces.testclass;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import javax.faces.component.html.HtmlForm;
import javax.faces.context.FacesContext;

/**
 * @since 1.0
 * @author balamurali
 */
public class DynamicFormCreator
{

    /**
     * @return the alternateForm
     */
    public HtmlForm getAlternateForm()
    {
        dynamicFormStatus = false;
        initializePageAttributes();
        return alternateForm;
    }

    /**
     * @param alternateForm the alternateForm to set
     */
    public void setAlternateForm(HtmlForm alternateForm)
    {

        this.alternateForm = alternateForm;
    }

    /**
     * @return the htmlForm
     */
    public HtmlForm getHtmlForm()
    {
        dynamicFormStatus = true;
        initializePageAttributes();
        return htmlForm;
    }

    /**
     * @param htmlForm the htmlForm to set
     */
    public void setHtmlForm(HtmlForm htmlForm)
    {

        this.htmlForm = htmlForm;
    }

    /**
     * @return the dynamicFormStatus
     */
    public boolean isDynamicFormStatus()
    {
        return dynamicFormStatus;
    }

    /**
     * @param dynamicFormStatus the dynamicFormStatus to set
     */
    public void setDynamicFormStatus(boolean dynamicFormStatus)
    {
        this.dynamicFormStatus = dynamicFormStatus;
    }

    private HtmlForm initForm;
    private HtmlForm alternateForm;
    private HtmlForm htmlForm;
    private boolean dynamicFormStatus;
    //
    private int parentRow;
    private int parentColumn;
    private int rowHeight;
    private int columnWidth;

    private String rowIndexInBean;
    private String columnIndexInBean;

    private int[][] arrayIndex;

    private boolean createButtonRendered;
    private boolean mergeButtonRendered;

    private List<DynamicFormCreatorBean> beanRowList = new ArrayList<DynamicFormCreatorBean>();
    private List<DynamicFormCreatorBean> beanColumnList = new ArrayList<DynamicFormCreatorBean>();

    private List<DynamicFormCreatorBean> tableBeanList = new ArrayList<DynamicFormCreatorBean>();

    private Map<String, List<Integer>> selectedIndexMap = new HashMap<String, List<Integer>>();

    private List<Integer> columnMergeList = new ArrayList<Integer>();

    public DynamicFormCreator()
    {
        System.out.println("entered into DynamicFormCreator Constructor !");
        System.out.println("parentRow : " + parentRow);
        System.out.println("parentColumn : " + parentColumn);
    }

    public String createButtonAction()
    {

        System.out.println("entered into createButtonAction !");

        if (parentRow == 0 && parentColumn == 0)
        {
            createButtonRendered = true;
        }
        else
        {
            if (parentRow != 0 && parentColumn != 0)
            {

                System.out.println("parentRow : " + parentRow);
                System.out.println("parentColumn : " + parentColumn);

                createButtonRendered = false;

                for (int i = 1; i <= parentRow; i++)
                {
                    DynamicFormCreatorBean tableCreatorBean = new DynamicFormCreatorBean();
                    tableCreatorBean.setRow(i);
                    
                    List<DynamicFormColumnCreatorBean> columnBeanDataList = new ArrayList<DynamicFormColumnCreatorBean>();
                    for (int j = 1; j <= parentColumn; j++)
                    {
                        DynamicFormColumnCreatorBean creatorBean = new DynamicFormColumnCreatorBean();
                        creatorBean.setColspan(0);
                        creatorBean.setColumnData(j);
                        columnBeanDataList.add(creatorBean);
                    }
                    tableCreatorBean.setColumnBeanDataList(columnBeanDataList);
                    tableBeanList.add(tableCreatorBean);
                }

            }
            else
            {
                createButtonRendered = true;
            }
        }

        return null;
    }

    public String getIndexValuesOnClick()
    {
        System.out.println("entered into getIndexValuesOnClick !");
        FacesContext context = FacesContext.getCurrentInstance();
        Map map = context.getExternalContext().getRequestParameterMap();

        rowIndexInBean = (String) map.get("rowIndex");
        columnIndexInBean = (String) map.get("columnIndex");

//        System.out.println("arrayIndexInBean : " + Arrays.toString(arrayIndex));
        System.out.println("rowIndexInBean : " + rowIndexInBean);
        System.out.println("columnIndexInBean : " + columnIndexInBean);

        columnMergeList.add(Integer.parseInt(columnIndexInBean) + 1);

        if (!selectedIndexMap.containsKey(rowIndexInBean))
        {
            selectedIndexMap.put(rowIndexInBean, columnMergeList);
        }
        else
        {
            selectedIndexMap.replace(rowIndexInBean, columnMergeList);
        }

        System.out.println("selectedIndexMap : " + selectedIndexMap);
        System.out.println("columnMergeList : " + columnMergeList);

        return null;
    }

    public String sampleMergeColumnButtonAction()
    {
        System.out.println("entered into sampleMergeColumnButtonAction !");

        System.out.println("rowIndexInBean : " + rowIndexInBean);
        System.out.println("columnMergeList : " + columnMergeList);
        System.out.println("columnMergeList.size() : " + columnMergeList.size());
        System.out.println("tableBeanList : " + tableBeanList.size());
        
        DynamicFormCreatorBean bean = tableBeanList.get(Integer.parseInt(rowIndexInBean));
  
        System.out.println("bean.getRow() : " + bean.getRow());

        for (DynamicFormColumnCreatorBean columnCreatorBean : bean.getColumnBeanDataList())
        {
            System.out.println("getColspan : " + columnCreatorBean.getColspan());
            System.out.println("getColumnData : " + columnCreatorBean.getColumnData());
        }
        
        List<DynamicFormColumnCreatorBean> columnBeanDataList = new ArrayList<DynamicFormColumnCreatorBean>();
        for (int j = 1; j <= columnMergeList.size(); j++)
        {
            DynamicFormColumnCreatorBean creatorBean = new DynamicFormColumnCreatorBean();
            creatorBean.setColspan(0);
            creatorBean.setColumnData(j);
            columnBeanDataList.add(creatorBean);
        }
        bean.setColumnBeanDataList(columnBeanDataList);
        
//        tableBeanList.remove(Integer.parseInt(rowIndexInBean));
        tableBeanList.add(Integer.parseInt(rowIndexInBean), bean);
        
        return null;
    }

    public String mergeColumnsButtonAction()
    {
        System.out.println("entered into mergeColumnsButtonAction !");

        System.out.println("rowIndexInBean : " + rowIndexInBean);
        System.out.println("columnMergeList : " + columnMergeList);

        if (tableBeanList != null && !tableBeanList.isEmpty())
        {
            System.out.println("tableBeanList.clear();");
            tableBeanList.clear();
        }

        for (int i = 1; i <= parentRow; i++)
        {
            System.out.println("i :" + i);
            DynamicFormCreatorBean tableCreatorBean = new DynamicFormCreatorBean();
            List<Integer> cList = new ArrayList<Integer>();
            for (int j = 1; j <= parentColumn; j++)
            {
                cList.add(j);
            }
            System.out.println("inside iteration !");
            if ((Integer.parseInt(rowIndexInBean) + 1) == i)
            {
                tableCreatorBean.setColspan(columnMergeList.size());
                cList.add(i);

                System.out.println("cList : " + cList);
            }
            else
            {
                tableCreatorBean.setColspan(0);

                System.out.println(" cList : " + cList);
            }
            tableCreatorBean.setRow(i);

            tableCreatorBean.setColumnList(cList);
            tableBeanList.add(tableCreatorBean);
        }
//         
//        System.out.println("tableBeanList size : " + tableBeanList.size());
        System.out.println("end of merge ButtonAction !");
        return null;
    }

    public String confirmCreateBackButtonAction()
    {
        System.out.println("entered into confirmCreateBackButtonAction !");

        return null;
    }

    public String clearCreatedDesignAction()
    {

        System.out.println("entered into clearCreatedDesignAction");
        if (tableBeanList != null && !tableBeanList.isEmpty())
        {
            tableBeanList.clear();
        }
        if (beanRowList != null && !beanRowList.isEmpty())
        {
            beanRowList.clear();
        }
        if (beanColumnList != null && !beanColumnList.isEmpty())
        {
            beanColumnList.clear();
        }
        if (columnMergeList != null && !columnMergeList.isEmpty())
        {
            columnMergeList.clear();
        }

        createButtonRendered = true;
        mergeButtonRendered = false;
        return null;
    }

    public void initializePageAttributes()
    {
        System.out.println("entered into initializePageAttributes method !");
        clearCreatedDesignAction();
    }

    /**
     * @return the initForm
     */
    public HtmlForm getInitForm()
    {
        if (dynamicFormStatus == false)
        {
            initForm = getHtmlForm();
        }
        else
        {
            initForm = getAlternateForm();
        }
        return initForm;
    }

    /**
     * @param initForm the initForm to set
     */
    public void setInitForm(HtmlForm initForm)
    {
        this.initForm = initForm;
    }

    /**
     * @return the parentRow
     */
    public int getParentRow()
    {
        return parentRow;
    }

    /**
     * @param parentRow the parentRow to set
     */
    public void setParentRow(int parentRow)
    {
        this.parentRow = parentRow;
    }

    /**
     * @return the parentColumn
     */
    public int getParentColumn()
    {
        return parentColumn;
    }

    /**
     * @param parentColumn the parentColumn to set
     */
    public void setParentColumn(int parentColumn)
    {
        this.parentColumn = parentColumn;
    }

    /**
     * @return the createButtonRendered
     */
    public boolean isCreateButtonRendered()
    {
        return createButtonRendered;
    }

    /**
     * @param createButtonRendered the createButtonRendered to set
     */
    public void setCreateButtonRendered(boolean createButtonRendered)
    {
        this.createButtonRendered = createButtonRendered;
    }

    /**
     * @return the beanRowList
     */
    public List<DynamicFormCreatorBean> getBeanRowList()
    {
        return beanRowList;
    }

    /**
     * @param beanRowList the beanRowList to set
     */
    public void setBeanRowList(List<DynamicFormCreatorBean> beanRowList)
    {
        this.beanRowList = beanRowList;
    }

    /**
     * @return the beanColumnList
     */
    public List<DynamicFormCreatorBean> getBeanColumnList()
    {
        return beanColumnList;
    }

    /**
     * @param beanColumnList the beanColumnList to set
     */
    public void setBeanColumnList(List<DynamicFormCreatorBean> beanColumnList)
    {
        this.beanColumnList = beanColumnList;
    }

    /**
     * @return the mergeButtonRendered
     */
    public boolean isMergeButtonRendered()
    {
        return mergeButtonRendered;
    }

    /**
     * @param mergeButtonRendered the mergeButtonRendered to set
     */
    public void setMergeButtonRendered(boolean mergeButtonRendered)
    {
        this.mergeButtonRendered = mergeButtonRendered;
    }

    /**
     * @return the rowHeight
     */
    public int getRowHeight()
    {
        return rowHeight;
    }

    /**
     * @param rowHeight the rowHeight to set
     */
    public void setRowHeight(int rowHeight)
    {
        this.rowHeight = rowHeight;
    }

    /**
     * @return the columnWidth
     */
    public int getColumnWidth()
    {
        return columnWidth;
    }

    /**
     * @param columnWidth the columnWidth to set
     */
    public void setColumnWidth(int columnWidth)
    {
        this.columnWidth = columnWidth;
    }

    /**
     * @return the tableBeanList
     */
    public List<DynamicFormCreatorBean> getTableBeanList()
    {
        return tableBeanList;
    }

    /**
     * @param tableBeanList the tableBeanList to set
     */
    public void setTableBeanList(List<DynamicFormCreatorBean> tableBeanList)
    {
        this.tableBeanList = tableBeanList;
    }

}
