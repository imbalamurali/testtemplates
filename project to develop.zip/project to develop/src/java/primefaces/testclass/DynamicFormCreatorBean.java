/*
 * DynamicFormCreatorBean.java
 *
 * Created on Apr 26, 2017, 6:15:49 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;

import java.util.ArrayList;
import java.util.List;


/**
 * @since 1.0
 * @author balamurali
 */
public class DynamicFormCreatorBean
{
    private int row;
    private int column;
    private int colspan;
    private List<Integer> columnList = new ArrayList<Integer>();
    private DynamicFormColumnCreatorBean columnCreatorBean;
    private List<DynamicFormColumnCreatorBean> columnBeanDataList = new ArrayList<DynamicFormColumnCreatorBean>();

    /**
     * @return the row
     */
    public int getRow()
    {
        return row;
    }

    /**
     * @param row the row to set
     */
    public void setRow(int row)
    {
        this.row = row;
    }

    /**
     * @return the colspan
     */
    public int getColspan()
    {
        return colspan;
    }

    /**
     * @param colspan the colspan to set
     */
    public void setColspan(int colspan)
    {
        this.colspan = colspan;
    }

    /**
     * @return the column
     */
    public int getColumn()
    {
        return column;
    }

    /**
     * @param column the column to set
     */
    public void setColumn(int column)
    {
        this.column = column;
    }

    /**
     * @return the columnList
     */
    public List<Integer> getColumnList()
    {
        return columnList;
    }

    /**
     * @param columnList the columnList to set
     */
    public void setColumnList(List<Integer> columnList)
    {
        this.columnList = columnList;
    }

    /**
     * @return the columnCreatorBean
     */
    public DynamicFormColumnCreatorBean getColumnCreatorBean()
    {
        return columnCreatorBean;
    }

    /**
     * @param columnCreatorBean the columnCreatorBean to set
     */
    public void setColumnCreatorBean(DynamicFormColumnCreatorBean columnCreatorBean)
    {
        this.columnCreatorBean = columnCreatorBean;
    }

    /**
     * @return the columnBeanDataList
     */
    public List<DynamicFormColumnCreatorBean> getColumnBeanDataList()
    {
        return columnBeanDataList;
    }

    /**
     * @param columnBeanDataList the columnBeanDataList to set
     */
    public void setColumnBeanDataList(List<DynamicFormColumnCreatorBean> columnBeanDataList)
    {
        this.columnBeanDataList = columnBeanDataList;
    }


    
}
