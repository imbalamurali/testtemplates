/*
 * EmployeeBenefitsBean.java
 *
 * Created on Jan 27, 2017, 11:35:11 AM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;


/**
 * @since 1.0
 * @author arun
 */
public class EmployeeBenefitsBean
{
    private String benefits;
    private String currency;
    private Double amount;

    /**
     * @return the benefits
     */
    public String getBenefits()
    {
        return benefits;
    }

    /**
     * @param benefits the benefits to set
     */
    public void setBenefits(String benefits)
    {
        this.benefits = benefits;
    }

    /**
     * @return the currency
     */
    public String getCurrency()
    {
        return currency;
    }

    /**
     * @param currency the currency to set
     */
    public void setCurrency(String currency)
    {
        this.currency = currency;
    }

    /**
     * @return the amount
     */
    public Double getAmount()
    {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(Double amount)
    {
        this.amount = amount;
    }
}