/*
 * EmployeeDetailBean.java
 *
 * Created on Jan 27, 2017, 11:27:21 AM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */
package primefaces.testclass;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @since 1.0
 * @author arun
 */
public class EmployeeDetailBean
{

    private Date month;
    private Date generatedOn;
    //
    private Double incomeTax;
    private Double netSalary;
    private Double grossSalary;
    private Double basicSalary;
    private Double totalAddition;
    private Double totalDeduction;
    //
    private List<EmployeeBenefitsBean> employeeAdditionBenefitsList = new ArrayList<EmployeeBenefitsBean>();
    private List<EmployeeBenefitsBean> employeeDeductionBenefitsList = new ArrayList<EmployeeBenefitsBean>();
    /**
     * @return the basicSalary
     */
    public Double getBasicSalary()
    {
        return basicSalary;
    }

    /**
     * @return the generatedOn
     */
    public Date getGeneratedOn()
    {
        return generatedOn;
    }

    /**
     * @return the incomeTax
     */
    public Double getIncomeTax()
    {
        return incomeTax;
    }

    /**
     * @return the month
     */
    public Date getMonth()
    {
        return month;
    }

    /**
     * @return the netSalary
     */
    public Double getNetSalary()
    {
        return netSalary;
    }

    /**
     * @param basicSalary the basicSalary to set
     */
    public void setBasicSalary(Double basicSalary)
    {
        this.basicSalary = basicSalary;
    }

    /**
     * @param generatedOn the generatedOn to set
     */
    public void setGeneratedOn(Date generatedOn)
    {
        this.generatedOn = generatedOn;
    }


    /**
     * @param incomeTax the incomeTax to set
     */
    public void setIncomeTax(Double incomeTax)
    {
        this.incomeTax = incomeTax;
    }

    /**
     * @param month the month to set
     */
    public void setMonth(Date month)
    {
        this.month = month;
    }

    /**
     * @param netSalary the netSalary to set
     */
    public void setNetSalary(Double netSalary)
    {
        this.netSalary = netSalary;
    }

    /**
     * @return the employeeAdditionBenefitsList
     */
    public List<EmployeeBenefitsBean> getEmployeeAdditionBenefitsList()
    {
        return employeeAdditionBenefitsList;
    }

    /**
     * @param employeeAdditionBenefitsList the employeeAdditionBenefitsList to set
     */
    public void setEmployeeAdditionBenefitsList(List<EmployeeBenefitsBean> employeeAdditionBenefitsList)
    {
        this.employeeAdditionBenefitsList = employeeAdditionBenefitsList;
    }

    /**
     * @return the employeeDeductionBenefitsList
     */
    public List<EmployeeBenefitsBean> getEmployeeDeductionBenefitsList()
    {
        return employeeDeductionBenefitsList;
    }

    /**
     * @param employeeDeductionBenefitsList the employeeDeductionBenefitsList to set
     */
    public void setEmployeeDeductionBenefitsList(List<EmployeeBenefitsBean> employeeDeductionBenefitsList)
    {
        this.employeeDeductionBenefitsList = employeeDeductionBenefitsList;
    }

    /**
     * @return the totalAddition
     */
    public Double getTotalAddition()
    {
        return totalAddition;
    }

    /**
     * @param totalAddition the totalAddition to set
     */
    public void setTotalAddition(Double totalAddition)
    {
        this.totalAddition = totalAddition;
    }

    /**
     * @return the totalDeduction
     */
    public Double getTotalDeduction()
    {
        return totalDeduction;
    }

    /**
     * @param totalDeduction the totalDeduction to set
     */
    public void setTotalDeduction(Double totalDeduction)
    {
        this.totalDeduction = totalDeduction;
    }

    /**
     * @return the grossSalary
     */
    public Double getGrossSalary()
    {
        return grossSalary;
    }

    /**
     * @param grossSalary the grossSalary to set
     */
    public void setGrossSalary(Double grossSalary)
    {
        this.grossSalary = grossSalary;
    }

}
