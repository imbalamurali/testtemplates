/*
 * EmployeePayRollBean.java
 *
 * Created on Jan 27, 2017, 2:32:25 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;

import java.util.ArrayList;
import java.util.List;


/**
 * @since 1.0
 * @author arun
 */
public class EmployeePayRollBean
{
    private String abc;
    private List<EmployeeDetailBean> employeeDetailBeanList = new ArrayList<EmployeeDetailBean>();

    /**
     * @return the employeeDetailBeanList
     */
    public List<EmployeeDetailBean> getEmployeeDetailBeanList()
    {
        return employeeDetailBeanList;
    }

    /**
     * @param employeeDetailBeanList the employeeDetailBeanList to set
     */
    public void setEmployeeDetailBeanList(List<EmployeeDetailBean> employeeDetailBeanList)
    {
        this.employeeDetailBeanList = employeeDetailBeanList;
    }

    /**
     * @return the abc
     */
    public String getAbc()
    {
        return abc;
    }

    /**
     * @param abc the abc to set
     */
    public void setAbc(String abc)
    {
        this.abc = abc;
    }
}