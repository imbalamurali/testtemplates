/*
 * LocationRadio.java
 *
 * Created on Dec 21, 2016, 2:12:02 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;

import java.util.ArrayList;
import java.util.List;
import javax.faces.component.html.HtmlForm;
import javax.faces.model.SelectItem;
import org.primefaces.event.map.StateChangeEvent;
import org.primefaces.model.map.LatLngBounds;


/**
 * @since 1.0
 * @author balamurali
 */
public class LocationRadio
{
    private HtmlForm initForm;
    private String urlLink;
    private String northEast;
    private String southWest;
    private String location;
    private String fmStation;
    private boolean fmStationComboBoxRendered;
    private List<SelectItem> fmStationList = new ArrayList<SelectItem>();
    private int zoomLevel;
    
    
    public String fmChangeComboBoxAction()
    {
        if (location.equalsIgnoreCase("Chennai"))
        {
            if (fmStation.equalsIgnoreCase("Suriyan FM"))
            {
//                urlLink = "https://www.youtube.com/user/SuryanFMChennai";
                urlLink = "http://www.liveonlineradio.net/sri-lanka/sooriyan-fm.htm";
            }
            else if (fmStation.equalsIgnoreCase("Radio Mirchi"))
            {

            }
            else if (fmStation.equalsIgnoreCase("Radio City"))
            {

            }
        }
        
        return null;
    }
    
    private void fetchChennaiFMStationList()
    {
        if (fmStationList != null && !fmStationList.isEmpty())
        {
            fmStationList.clear();
        }
        fmStationList.add(new  SelectItem("Suriyan FM"));
        fmStationList.add(new  SelectItem("Radio Mirchi"));
        fmStationList.add(new  SelectItem("Radio City"));
        fmStationList.add(new  SelectItem("All India Radio"));
        
        fmStation = fmStationList.get(0).getValue().toString();
        if (fmStation.equalsIgnoreCase("Suriyan FM"))
        {
//            urlLink = "https://www.youtube.com/user/SuryanFMChennai";
            urlLink = "http://www.liveonlineradio.net/sri-lanka/sooriyan-fm.htm";
        }
    }
    
    public void onStateChange(StateChangeEvent event) 
    {
        fmStationComboBoxRendered = false;
        location = "Cannot Recognize Location";
        LatLngBounds bounds = event.getBounds();
        zoomLevel = event.getZoomLevel();

        System.out.println("zoomLevel : " + zoomLevel);
        System.out.println("bounds.getNorthEast() : " + bounds.getNorthEast().toString());
        northEast = bounds.getNorthEast().toString();
        southWest = bounds.getSouthWest().toString();
        System.out.println("bounds.getSouthWest() : " + bounds.getSouthWest().toString());

        if (bounds.getNorthEast().getLat() > 11.00
                && bounds.getNorthEast().getLng() > 80.00 && bounds.getSouthWest().getLat() > 11.00
                && bounds.getSouthWest().getLng() > 78.00)
        {
            System.out.println("location is chennai !!!!");
            location = "Chennai";
            fmStationComboBoxRendered = true;
            fetchChennaiFMStationList();
        }
        
//        if(location.equalsIgnoreCase("Chennai"))
//        {
//            
//        }
        
//        if(bounds.getNorthEast().getLat()  )
          
//        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Zoom Level", String.valueOf(zoomLevel)));
//        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Center", event.getCenter().toString()));
//        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "NorthEast", bounds.getNorthEast().toString()));
//        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "SouthWest", bounds.getSouthWest().toString()));
    }
//      
//    public void onPointSelect(PointSelectEvent event) 
//    {
//        LatLng latlng = event.getLatLng();
//        
//        System.out.println("latlng.getLat() : "+latlng.getLat());
//        System.out.println("latlng.getLng : "+latlng.getLng());
//        
//          
////        addMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, "Point Selected", "Lat:" + latlng.getLat() + ", Lng:" + latlng.getLng()));
//    }

    /**
     * @return the initForm
     */
    public HtmlForm getInitForm()
    {
        return initForm;
    }

    /**
     * @param initForm the initForm to set
     */
    public void setInitForm(HtmlForm initForm)
    {
        this.initForm = initForm;
    }

    /**
     * @return the location
     */
    public String getLocation()
    {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(String location)
    {
        this.location = location;
    }

    /**
     * @return the northEast
     */
    public String getNorthEast()
    {
        return northEast;
    }

    /**
     * @param northEast the northEast to set
     */
    public void setNorthEast(String northEast)
    {
        this.northEast = northEast;
    }

    /**
     * @return the southWest
     */
    public String getSouthWest()
    {
        return southWest;
    }

    /**
     * @param southWest the southWest to set
     */
    public void setSouthWest(String southWest)
    {
        this.southWest = southWest;
    }

    /**
     * @return the zoomLevel
     */
    public int getZoomLevel()
    {
        return zoomLevel;
    }

    /**
     * @param zoomLevel the zoomLevel to set
     */
    public void setZoomLevel(int zoomLevel)
    {
        this.zoomLevel = zoomLevel;
    }

    /**
     * @return the fmStation
     */
    public String getFmStation()
    {
        return fmStation;
    }

    /**
     * @param fmStation the fmStation to set
     */
    public void setFmStation(String fmStation)
    {
        this.fmStation = fmStation;
    }

    /**
     * @return the fmStationComboBoxRendered
     */
    public boolean isFmStationComboBoxRendered()
    {
        return fmStationComboBoxRendered;
    }

    /**
     * @param fmStationComboBoxRendered the fmStationComboBoxRendered to set
     */
    public void setFmStationComboBoxRendered(boolean fmStationComboBoxRendered)
    {
        this.fmStationComboBoxRendered = fmStationComboBoxRendered;
    }
    /**
     * @return the urlLink
     */
    public String getUrlLink()
    {
        return urlLink;
    }

    /**
     * @param urlLink the urlLink to set
     */
    public void setUrlLink(String urlLink)
    {
        this.urlLink = urlLink;
    }

    /**
     * @return the fmStationList
     */
    public List<SelectItem> getFmStationList()
    {
        return fmStationList;
    }

    /**
     * @param fmStationList the fmStationList to set
     */
    public void setFmStationList(List<SelectItem> fmStationList)
    {
        this.fmStationList = fmStationList;
    }
    
}
