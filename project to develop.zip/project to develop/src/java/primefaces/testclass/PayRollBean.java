/*
 * PayRollBean.java
 *
 * Created on Jan 27, 2017, 11:25:52 AM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;

import java.util.ArrayList;
import java.util.List;


/**
 * @since 1.0
 * @author arun
 */
public class PayRollBean
{

    private String employeeName;
    private List<EmployeePayRollBean> employeePayRollBeanList = new ArrayList<EmployeePayRollBean>();
    
    /**
     * @return the employeeName
     */
    public String getEmployeeName()
    {
        return employeeName;
    }

    /**
     * @param employeeName the employeeName to set
     */
    public void setEmployeeName(String employeeName)
    {
        this.employeeName = employeeName;
    }

    /**
     * @return the employeePayRollBeanList
     */
    public List<EmployeePayRollBean> getEmployeePayRollBeanList()
    {
        return employeePayRollBeanList;
    }

    /**
     * @param employeePayRollBeanList the employeePayRollBeanList to set
     */
    public void setEmployeePayRollBeanList(List<EmployeePayRollBean> employeePayRollBeanList)
    {
        this.employeePayRollBeanList = employeePayRollBeanList;
    }

}