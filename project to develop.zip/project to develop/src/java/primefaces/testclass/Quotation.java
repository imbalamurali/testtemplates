/*
 * Quotation.java
 *
 * Created on Jan 12, 2017, 2:48:11 PM
 *
 * Copyright © 2013-2014 InfoMindz R&D Sdn. Bhd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * InfoMindz R&D Sdn. Bhd.("Confidential Information"). You shall
 * not disclose such Confidential Information and shall use it only
 * in accordance with the terms of the license agreement you entered
 * into with InfoMindz.
 */

package primefaces.testclass;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.faces.component.html.HtmlForm;


/**
 * @since 1.0
 * @author balamurali
 */
public class Quotation
{
    private HtmlForm initForm;
    private List<PayRollBean> payRollBeanList = new ArrayList<PayRollBean>();

    private void fetchQuotationValues()
    {
        PayRollBean firstBean = new PayRollBean();

        EmployeePayRollBean secondBean = new EmployeePayRollBean();

        EmployeeDetailBean thirdBean = new EmployeeDetailBean();
        thirdBean.setMonth(new Date());

        List<PayRollBean> list1 = new ArrayList<PayRollBean>();
        List<EmployeePayRollBean> list2 = new ArrayList<EmployeePayRollBean>();
        List<EmployeeDetailBean> list3 = new ArrayList<EmployeeDetailBean>();

        list2.add(secondBean);

        thirdBean.setMonth(new Date());
        list3.add(thirdBean);
        secondBean.setEmployeeDetailBeanList(list3);
        list2.add(secondBean);
        firstBean.setEmployeePayRollBeanList(list2);

        payRollBeanList.add(firstBean);
    }
    
    
    private void initializePageAttributes()
    {
        fetchQuotationValues();
    }

    /**
     * @return the initForm
     */
    public HtmlForm getInitForm()
    {
        initializePageAttributes();
        return initForm;
    }

    /**
     * @param initForm the initForm to set
     */
    public void setInitForm(HtmlForm initForm)
    {
        this.initForm = initForm;
    }

    /**
     * @return the payRollBeanList
     */
    public List<PayRollBean> getPayRollBeanList()
    {
        return payRollBeanList;
    }

    /**
     * @param payRollBeanList the payRollBeanList to set
     */
    public void setPayRollBeanList(List<PayRollBean> payRollBeanList)
    {
        this.payRollBeanList = payRollBeanList;
    }
    
}
